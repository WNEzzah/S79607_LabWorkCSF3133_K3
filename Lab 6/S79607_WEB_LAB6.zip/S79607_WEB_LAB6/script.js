const questions = [
    {
        q: "Which tag is used to link an external JS file?",
        options: ["<script>", "<js>", "<link>", "<code>"],
        answer: "<script>"
    },
    {
        q: "Which method gets an element by ID?",
        options: ["querySelectorAll", "getElementById", "getElementsByTag", "findId"],
        answer: "getElementById"
    },
    {
        q: "Which CSS property adds space inside an element's border?",
        options: ["margin", "padding", "spacing", "border-width"],
        answer: "padding"
    },
    {
        q: "Which event runs when right-clicking a page?",
        options: ["click", "contextmenu", "onsubmit", "keydown"],
        answer: "contextmenu"
    }
];

let quizList = [];
let currentIndex = 0;
let score = 0;
let timeLeft = 15;
let timer;
let checked = false;

function shuffleQuestions() {
    quizList = [...questions];
    for (let i = quizList.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [quizList[i], quizList[j]] = [quizList[j], quizList[i]];
    }
}

function startTimer() {
    clearInterval(timer);
    timeLeft = 15;
    document.getElementById("timer").textContent = "Time left: " + timeLeft + "s";

    timer = setInterval(() => {
        timeLeft--;
        document.getElementById("timer").textContent = "Time left: " + timeLeft + "s";

        if (timeLeft <= 0) {
            clearInterval(timer);
            if (!checked) {
                checked = true;
                document.getElementById("feedback").textContent =
                    "Time's up! Answer: " + quizList[currentIndex].answer;
                document.getElementById("actionBtn").textContent = "Next";
            }
        }
    }, 1000);
}

function displayQuestion() {
    checked = false;
    const item = quizList[currentIndex];
    document.getElementById("question").textContent =
        (currentIndex + 1) + ". " + item.q;

    const optionsDiv = document.getElementById("options");
    optionsDiv.innerHTML = "";

    item.options.forEach(opt => {
        const label = document.createElement("label");
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "choice";
        radio.value = opt;
        label.appendChild(radio);
        label.appendChild(document.createTextNode(" " + opt));
        optionsDiv.appendChild(label);
    });

    document.getElementById("feedback").textContent = "";
    document.getElementById("actionBtn").textContent = "Submit";
    startTimer();
}

function checkAnswer() {
    const selected = document.querySelector('input[name="choice"]:checked');
    if (!selected) {
        alert("Pick an answer first.");
        return;
    }

    clearInterval(timer);
    checked = true;
    const correctAnswer = quizList[currentIndex].answer;

    if (selected.value === correctAnswer) {
        score++;
        document.getElementById("feedback").textContent = "Correct!";
    } else {
        document.getElementById("feedback").textContent = "Wrong. Answer: " + correctAnswer;
    }

    document.getElementById("score").textContent = "Score: " + score + " / " + quizList.length;
    document.getElementById("actionBtn").textContent =
        currentIndex === quizList.length - 1 ? "Finish" : "Next";
}

function nextQuestion() {
    currentIndex++;
    if (currentIndex < quizList.length) {
        displayQuestion();
    } else {
        clearInterval(timer);
        document.getElementById("quiz-box").innerHTML = "<h3>Quiz done!</h3>";
        document.getElementById("feedback").textContent = "";
        document.getElementById("score").textContent =
            "Final Score: " + score + " / " + quizList.length;
    }
}

function handleAction() {
    if (!checked) {
        checkAnswer();
    } else {
        nextQuestion();
    }
}

function startQuiz() {
    shuffleQuestions();
    currentIndex = 0;
    score = 0;
    document.getElementById("score").textContent = "Score: 0 / " + quizList.length;
    displayQuestion();
}

startQuiz();